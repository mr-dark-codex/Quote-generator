import React from "react";

const QuoteButton = ({ getRandomQuote }) => {
  return (
    <button className="quote-button" onClick={getRandomQuote}>
      Get Random Quote
    </button>
  );
};

export default QuoteButton;
