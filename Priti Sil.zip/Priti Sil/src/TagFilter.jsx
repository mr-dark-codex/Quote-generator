import React from "react";

const TagFilter = ({ selectedTag, filterQuotesByTag }) => {
  const tags = ["All", "Motivation", "Inspiration", "Perseverance", "Action", "Happiness", "Work"];

  return (
    <>
    <div className="tag-filter">
      <label>Filter by Tag:</label>
      <select
        value={selectedTag}
        onChange={(e) => filterQuotesByTag(e.target.value)}
      >
        {tags.map((tag) => (
          <option key={tag} value={tag}>
            {tag}
          </option>
        ))}
      </select>
    </div>
    </>
  );
};

export default TagFilter;
