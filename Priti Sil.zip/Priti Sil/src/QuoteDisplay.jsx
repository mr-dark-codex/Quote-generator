import React from "react";

const QuoteDisplay = ({ quote }) => {
  if (!quote.text) {
    return <p>Loading...</p>;
  }

  return (
    <div className="quote-display">
      <p className="quote-text">{`"${quote.text}"`}</p>
      <p className="quote-author">- {quote.author}</p>
      <p className="quote-tag">{`Tag: ${quote.tag}`}</p>
    </div>
  );
};

export default QuoteDisplay;
