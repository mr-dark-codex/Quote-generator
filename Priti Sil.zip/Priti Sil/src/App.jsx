import './App.css'
import React, { useState, useEffect } from "react";
import QuoteDisplay from "./QuoteDisplay.jsx";
import QuoteButton from "./QuoteButton.jsx";
import TagFilter from "./TagFilter.jsx";
import CopyButton from "./CopyButton.jsx";
import "./App.css";

const quotesData = [
  { text: "The best way to get started is to quit talking and begin doing.", author: "Walt Disney", tag: "Motivation" },
  { text: "Success is not final, failure is not fatal: It is the courage to continue that counts.", author: "Winston Churchill", tag: "Inspiration" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius", tag: "Perseverance" },
  { text: "Act as if what you do makes a difference. It does.", author: "William James", tag: "Action" },
  { text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson", tag: "Motivation" },
  { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt", tag: "Inspiration" },
  { text: "Happiness depends upon ourselves.", author: "Aristotle", tag: "Happiness" },
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs", tag: "Work" },
];

const App = () => {
  const [currentQuote, setCurrentQuote] = useState({});
  const [selectedTag, setSelectedTag] = useState("All");
  const [filteredQuotes, setFilteredQuotes] = useState(quotesData);

  useEffect(() => {
    const savedQuote = JSON.parse(localStorage.getItem("lastQuote"));
    if (savedQuote) {
      setCurrentQuote(savedQuote);
    } else {
      getRandomQuote();
    }
  }, []);

  const getRandomQuote = () => {
    const randomQuote = filteredQuotes[Math.floor(Math.random() * filteredQuotes.length)];
    setCurrentQuote(randomQuote);
    localStorage.setItem("lastQuote", JSON.stringify(randomQuote));
  };

  const filterQuotesByTag = (tag) => {
    setSelectedTag(tag);
    if (tag === "All") {
      setFilteredQuotes(quotesData);
    } else {
      setFilteredQuotes(quotesData.filter((quote) => quote.tag === tag));
    }
  };


  return (

      <div className="App">
        <h1>Random Quotes App</h1>
        <TagFilter selectedTag={selectedTag} filterQuotesByTag={filterQuotesByTag} />
        <QuoteDisplay quote={currentQuote} />
        <div className="buttons">
          <QuoteButton getRandomQuote={getRandomQuote} />
          <CopyButton quote={currentQuote} />
        </div>
      </div>
  )
}

export default App
