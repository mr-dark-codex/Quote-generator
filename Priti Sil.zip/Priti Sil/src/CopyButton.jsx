import React from "react";

const CopyButton = ({ quote }) => {
  const copyToClipboard = () => {
    navigator.clipboard.writeText(`"${quote.text}" - ${quote.author}`).then(() => {
      alert("Quote copied to clipboard!");
    });
  };

  return (
    <button className="copy-button" onClick={copyToClipboard}>
      Copy Quote
    </button>
  );
};

export default CopyButton;
