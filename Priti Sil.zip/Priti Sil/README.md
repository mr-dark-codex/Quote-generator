This is a simple web application built with React that displays random quotes. Users can click a button to generate a new quote, filter quotes by tags and copy a quote to the clipboard. The app saves the last seen quote in localStorage.


Steps for installing it:

1. Download and extract the zip file.
2. Open terminal and go to the folder.
3. Then npm install.
4. Then npm run dev.